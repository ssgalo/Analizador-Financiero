import Link from "next/link"
import { Button } from "@/components/ui/button"

export default function HomePage() {
  return (
    <div className="min-h-screen bg-background flex items-center justify-center p-4">
      <div className="text-center space-y-8">
        <div>
          <div className="inline-flex items-center justify-center w-16 h-16 bg-primary rounded-xl mb-6">
            <div className="w-8 h-8 bg-primary-foreground rounded-md"></div>
          </div>
          <h1 className="text-4xl font-semibold tracking-tight text-balance mb-4">Bienvenido a nuestra aplicación</h1>
          <p className="text-lg text-muted-foreground max-w-md mx-auto leading-relaxed">
            Una experiencia moderna y elegante te espera. Comienza tu viaje con nosotros.
          </p>
        </div>

        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <Button asChild size="lg" className="h-12 px-8">
            <Link href="/login">Iniciar sesión</Link>
          </Button>
          <Button asChild variant="outline" size="lg" className="h-12 px-8 bg-transparent">
            <Link href="/register">Crear cuenta</Link>
          </Button>
        </div>
      </div>
    </div>
  )
}
