export function FinancialLogo({ className = "w-12 h-12" }: { className?: string }) {
  return (
    <div
      className={`${className} bg-gradient-to-br from-blue-600 to-blue-800 rounded-xl flex items-center justify-center shadow-lg`}
    >
      <svg viewBox="0 0 24 24" fill="none" className="w-2/3 h-2/3 text-white" xmlns="http://www.w3.org/2000/svg">
        {/* Gráfico de barras */}
        <rect x="3" y="12" width="3" height="9" fill="currentColor" opacity="0.8" />
        <rect x="7" y="8" width="3" height="13" fill="currentColor" />
        <rect x="11" y="14" width="3" height="7" fill="currentColor" opacity="0.8" />
        <rect x="15" y="6" width="3" height="15" fill="currentColor" />
        <rect x="19" y="10" width="3" height="11" fill="currentColor" opacity="0.8" />

        {/* Línea de tendencia */}
        <path
          d="M4.5 15L8.5 11L12.5 17L16.5 9L20.5 13"
          stroke="currentColor"
          strokeWidth="2"
          strokeLinecap="round"
          strokeLinejoin="round"
          opacity="0.9"
        />

        {/* Símbolo de dinero */}
        <circle cx="20" cy="4" r="2" fill="currentColor" opacity="0.9" />
        <text x="20" y="5.5" textAnchor="middle" className="text-xs font-bold fill-blue-800">
          $
        </text>
      </svg>
    </div>
  )
}
